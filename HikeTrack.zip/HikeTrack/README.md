# HikeTrack
Este proyecto tiene como objetivo el desarrollo de una aplicación que permita a los senderistas elegir nuevas rutas, ver sus estadisticas y contactarse con otros que tengan aficion en este hobbie.

## Autores
- [@CryoWarrior](https://github.com/CryoWarrior)
- [@Jgon-2301](https://github.com/Jgon-2301)
- [@MariadlRosa-1224](https://github.com/MariadlRosa-1224)
- [@richieeeeeg](https://github.com/richieeeeeg)
