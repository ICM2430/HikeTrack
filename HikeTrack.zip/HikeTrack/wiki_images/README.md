This folder contains images for the wiki
